// server.js — Exercise 06: Preparing for POST Data
// Goal: Configure Express to understand incoming JSON data.

import express from 'express';

const app = express();
const PORT = 3000;

// ─────────────────────────────────────────────
// Middleware: express.json()
// CRITICAL: Without this middleware, req.body will be undefined.
// It parses incoming requests with a Content-Type of application/json
// and populates req.body with the parsed JavaScript object.
// ─────────────────────────────────────────────
app.use(express.json());

// ─────────────────────────────────────────────
// Route: POST /echo
// Reads the JSON body sent by the client and echoes it back.
//
// How to test with Apidog:
//   1. Create a New Request → Method: POST
//   2. URL: http://localhost:3000/echo
//   3. Body tab → JSON → type: { "name": "Dara" }
//   4. Hit Send — you should see the echoed object in the response!
// ─────────────────────────────────────────────
app.post('/echo', (req, res) => {
    const body = req.body; // Populated by express.json() middleware
    res.status(200).json({
        message: 'Here is what you sent:',
        received: body,
    });
});

// ─────────────────────────────────────────────
// Start the server
// ─────────────────────────────────────────────
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
