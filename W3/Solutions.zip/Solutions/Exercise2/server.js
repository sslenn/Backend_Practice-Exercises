// server.js — Exercise 02: The Express Foundation
// Goal: Initialize an Express application and start the server.

import express from 'express';

const app = express();
const PORT = 3000;

// ─────────────────────────────────────────────
// Route: GET /
// Returns a simple welcome message to confirm the server is running
// ─────────────────────────────────────────────
app.get('/', (req, res) => {
    res.send('Hello from Express!');
});

// ─────────────────────────────────────────────
// Start the server
// ─────────────────────────────────────────────
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
