// server.js — Exercise 08: The "Auto-File" Server (express.static)
// Goal: Understand how Express simplifies serving CSS, Images, or HTML
//       files without manual routing.

import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const app = express();
const PORT = 3000;

// ES Modules do not have __dirname — we recreate it using import.meta.url
const __filename = fileURLToPath(import.meta.url);
const __dirname  = path.dirname(__filename);

// ─────────────────────────────────────────────
// Middleware: express.static()
// Serves every file inside the "public/" folder automatically.
// No individual routes needed for index.html, style.css, images, etc.
//
// Visiting http://localhost:3000/        → serves public/index.html
// Visiting http://localhost:3000/style.css → serves public/style.css
// ─────────────────────────────────────────────
app.use(express.static(path.join(__dirname, 'public')));

// ─────────────────────────────────────────────
// Any API routes go below the static middleware
// ─────────────────────────────────────────────
app.get('/api/info', (req, res) => {
    res.json({ message: 'This is an API endpoint, separate from static files.' });
});

// ─────────────────────────────────────────────
// Start the server
// ─────────────────────────────────────────────
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
    console.log(`Open http://localhost:${PORT} to see the static HTML page.`);
});
