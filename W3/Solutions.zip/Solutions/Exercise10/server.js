// server.js — Exercise 10: Enhance an API with Middleware
// Applies logging, validation, and (bonus) auth middleware to the course API.

import express from 'express';
import courses from '../Exercise9/course.js'; // Reuse course data from Ex09

import requestLogger   from './logger.js';
import validateCreditQuery from './validateQuery.js';
import tokenAuth       from './auth.js';

const app = express();
const PORT = 3000;

// ─────────────────────────────────────────────
// Q1 – Apply the logger middleware GLOBALLY
// Logs method, path, query params, and ISO timestamp for every request.
// ─────────────────────────────────────────────
app.use(requestLogger);

// ─────────────────────────────────────────────
// (Optional) Q3 Bonus – Apply token auth globally.
// Uncomment the line below to require ?token=xyz123 on ALL routes.
// ─────────────────────────────────────────────
// app.use(tokenAuth);

// ─────────────────────────────────────────────
// Route: GET /departments/:dept/courses
//
// Middleware chain for this route:
//   1. validateCreditQuery  → Q2: validates minCredits / maxCredits
//   2. tokenAuth (optional) → Q3 Bonus: can be inserted here instead of globally
//   3. Route handler        → filters and returns course data
// ─────────────────────────────────────────────
app.get(
    '/departments/:dept/courses',
    validateCreditQuery,   // Q2: route-specific validation middleware
    // tokenAuth,          // Q3 Bonus: uncomment to enable token auth on this route only
    (req, res) => {
        const { dept } = req.params;
        const { level, minCredits, maxCredits, semester, instructor } = req.query;

        // By the time we reach here, validateCreditQuery has already
        // confirmed minCredits and maxCredits are valid integers (if present).
        const min = minCredits !== undefined ? parseInt(minCredits, 10) : undefined;
        const max = maxCredits !== undefined ? parseInt(maxCredits, 10) : undefined;

        // Filter courses using all provided criteria
        const filtered = courses.filter((course) => {
            if (course.department.toLowerCase() !== dept.toLowerCase())            return false;
            if (level     && course.level.toLowerCase()     !== level.toLowerCase())     return false;
            if (min !== undefined && course.credits < min)                         return false;
            if (max !== undefined && course.credits > max)                         return false;
            if (semester  && course.semester.toLowerCase()  !== semester.toLowerCase())  return false;
            if (instructor && !course.instructor.toLowerCase().includes(instructor.toLowerCase())) return false;
            return true;
        });

        res.status(200).json({
            results: filtered,
            meta: { total: filtered.length },
        });
    }
);

// ─────────────────────────────────────────────
// Start the server
// ─────────────────────────────────────────────
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
