// category controller
import CategoryModel from "../models/category.js";
import ProductModel from "../models/product.js";
// import Order from "./order.js";
class CategoryController {
  //Get all categories
  static async getAllCategories(req, res) {
    try {
      const categories = await CategoryModel.findAll();
      res.status(200).json(categories);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch categories" });
    }
  }

  // Get products by category ID
  static async getCategoryProducts(req, res) {
    // 1. Get the categoryId from request parameters
    // 2. Try to find the category by its primary key, including its products
    // 3. If category not found, return 404 error
    // 4. If found, return category with products as JSON
    // 5. Catch any errors and return 500 error
    const id = req.params.id;
    try {
      const category = await CategoryModel.findByPk(id, {
        include: [{ model: ProductModel, as: "products" }],
      });
      if (!category)
        return res.status(404).json({ error: "Category not found" });
      res.status(200).json(category);
    } catch {
      res.status(500).json({ error: "Failed to fetch category products" });
    }
  }
}

export default CategoryController;
