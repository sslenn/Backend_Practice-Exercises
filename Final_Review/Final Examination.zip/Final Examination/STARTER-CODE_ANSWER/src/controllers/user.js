// src/controllers/user.js
import UserModel from "../models/user.js";
import OrderModel from "../models/order.js";
import ProductModel from "../models/product.js";
import jwt from "jsonwebtoken";

export const TOKEN_SECRET = "password";

class UserController {
  static async getAllUsers(req, res) {
    try {
      const users = await UserModel.findAll();
      res.status(200).json(users);
    } catch {
      res.status(500).json({ error: "Failed to fetch users" });
    }
  }

  static async login(req, res) {
    try {
      const { email, password } = req.body;
      const user = await UserModel.findOne({ where: { email } });
      if (!user || user.password !== password) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      const token = jwt.sign({ id: user.id }, TOKEN_SECRET, {
        expiresIn: "1h",
      });
      res.status(200).json({ user, token });
    } catch {
      res.status(500).json({ error: "Login failed" });
    }
  }

  static async getCurrentUser(req, res) {
    try {
      res.status(200).json(req.user);
    } catch {
      res.status(500).json({ error: "Failed to fetch current user" });
    }
  }

  static async getUserOrders(req, res) {
    try {
      const userId = req.user.id;
      const orders = await OrderModel.findAll({
        where: { userId },
        include: [{ model: ProductModel, as: "product" }],
      });
      res.status(200).json(orders);
    } catch {
      res.status(500).json({ error: "Failed to fetch user orders" });
    }
  }
}

export default UserController;
