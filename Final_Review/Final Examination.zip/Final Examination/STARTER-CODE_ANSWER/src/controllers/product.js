import ProductModel from "../models/product.js";
import { Op } from "sequelize";

class ProductController {
  // Get all products
  static async getAllProducts(req, res) {
    try {
      const products = await ProductModel.findAll();
      res.status(200).json(products);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch products" });
    }
  }

  // Create a new product
  static async createProduct(req, res) {
    const { name, price, categoryId } = req.body;

    const product = await ProductModel.create({
      name,
      price,
      categoryId,
    });

    try {
      const product = await ProductModel.create(req.body);
      res.status(201).json(product);
    } catch (error) {
      res.status(400).json({ error: "Failed to create product" });
    }
  }

  static async deleteProduct(req, res) {
    try {
      const id = req.params.id;
      const deleted = await ProductModel.destroy({ where: { id } });
      if (deleted)
        return res
          .status(200)
          .json({ message: "Product deleted successfully" });
      res.status(404).json({ error: "Product not found" });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete product" });
    }
  }

  static async getProductsByPriceRange(req, res) {
    try {
      const { min, max } = req.query;
      const products = await ProductModel.findAll({
        where: { price: { [Op.between]: [Number(min), Number(max)] } },
      });
      res.status(200).json(products);
    } catch (error) {
      res
        .status(500)
        .json({ error: "Failed to fetch products by price range" });
    }
  }
}

export default ProductController;
