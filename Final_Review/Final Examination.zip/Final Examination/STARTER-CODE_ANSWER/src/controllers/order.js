// src/controllers/order.js
import OrderModel from "../models/order.js";
import ProductModel from "../models/product.js";

class OrderController {
  static async getUserOrders(req, res) {
    const userId = req.params.id;
    const orders = await OrderModel.findAll({
      where: { userId },
      include: [{ model: ProductModel, as: "product" }],
    });
    res.status(200).json(orders);
  }

  static async createOrder(req, res) {
    const { quantity, status, productId, userId } = req.body;
    const order = await OrderModel.create({
      quantity,
      status,
      productId,
      userId,
    });
    res.status(201).json(order);
  }

  static async updateOrderStatus(req, res) {
    const id = req.params.id;
    await OrderModel.update({ status: req.body.status }, { where: { id } });
    const updated = await OrderModel.findByPk(id);
    res.status(200).json(updated);
  }
}

export default OrderController;
