import { Router } from "express";
import OrderController from "../controllers/order.js";

const orderRouter = Router();

orderRouter.get("/user/:id/orders", OrderController.getUserOrders);
orderRouter.post("/order/create", OrderController.createOrder);
orderRouter.put("/order/:id/update-status", OrderController.updateOrderStatus);

export default orderRouter;
