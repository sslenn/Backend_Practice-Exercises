import { Router } from "express";
import ProductController from "../controllers/product.js";

const productRouter = Router();

// TODO: Add  required products routes
productRouter.get("/:id", ProductController.getAllProducts);
productRouter.post("/:id", ProductController.createProduct);
productRouter.get("/", ProductController.getProductsByPriceRange);
productRouter.delete("/:id", ProductController.deleteProduct);
// productRouter.get(
//   "/category/:id/products",
//   ProductController.getCategoryProducts
// );

export default productRouter;
