// category route
import { Router } from "express";
import CategoryController from "../controllers/category.js";

const categoryRouter = Router();

categoryRouter.get("/all", CategoryController.getAllCategories);

// TODO: Add route to get products for a specific category by ID
categoryRouter.get("/:id/products", CategoryController.getCategoryProducts);

export default categoryRouter;
