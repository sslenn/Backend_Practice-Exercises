// src/routes/user.js
import { Router } from "express";
import UserController from "../controllers/user.js";
import auth from "../middlewares/auth.js";

const userRouter = Router();

userRouter.get("/all", UserController.getAllUsers);
userRouter.post("/login", UserController.login);
userRouter.get("/current-user", auth, UserController.getCurrentUser);
userRouter.get("/my-orders", auth, UserController.getUserOrders);

export default userRouter;


