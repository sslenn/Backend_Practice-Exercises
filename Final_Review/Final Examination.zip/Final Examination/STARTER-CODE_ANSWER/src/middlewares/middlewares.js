// src/middlewares/ValidatorMiddlewares.js
class ValidatorMiddlewares {
  /**
   * Order Middlewares
   */

  // Middleware to validate order creation
  static orderCreationValidated = (req, res, next) => {
    const { quantity, status, productId, userId } = req.body;

    // All fields required
    if (
      quantity === undefined ||
      status === undefined ||
      productId === undefined ||
      userId === undefined
    ) {
      return res
        .status(400)
        .json({ error: "quantity, status, productId and userId are required" });
    }

    // Quantity must be > 0
    if (typeof quantity !== "number" || quantity <= 0) {
      return res
        .status(400)
        .json({ error: "Quantity must be a number greater than 0" });
    }

    // Status must be one of PENDING, COMPLETED, CANCELED
    const validStatuses = ["PENDING", "COMPLETED", "CANCELED"];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        error: "Status must be one of: PENDING, COMPLETED, CANCELED",
      });
    }

    next();
  };

  // Middleware to validate order update status
  static orderUpdateStatusValidated = (req, res, next) => {
    const { status } = req.body;

    // Status must be COMPLETED or CANCELED
    const validUpdates = ["COMPLETED", "CANCELED"];
    if (!validUpdates.includes(status)) {
      return res
        .status(400)
        .json({ error: "Status must be either COMPLETED or CANCELED" });
    }

    next();
  };
}

export default ValidatorMiddlewares;
