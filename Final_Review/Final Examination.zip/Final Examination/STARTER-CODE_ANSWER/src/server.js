// src/server.js
import express from "express";
import cors from "cors";
import seedDatabase from "./db/seeder.js";
import { setupAssociations } from "./models/associations.js";
import productRouter from "./routers/product.js";
import categoryRouter from "./routers/category.js";
import userRouter from "./routers/user.js";
import orderRouter from "./routers/order.js";

(async () => {
  // 1. Setup associations and seed DB
  setupAssociations();
  await seedDatabase();

  // 2. Express setup
  const app = express();
  app.use(cors());
  app.use(express.json());

  // 3. Routes
  app.use("/api/products", productRouter);
  app.use("/api/categories", categoryRouter);
  app.use("/api/users", userRouter);
  app.use("/api/orders", orderRouter);

  // 4. Start server
  const PORT = 4000;
  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
})();
