// src/models/order.js
import { DataTypes, Model } from "sequelize";
import sequelize from "../db/database.js";

class Order extends Model {}

Order.init(
  {
    quantity: { type: DataTypes.INTEGER, allowNull: false },
    status:   { type: DataTypes.STRING,  allowNull: false },
    userId:   { type: DataTypes.INTEGER, allowNull: false },
    productId:{ type: DataTypes.INTEGER, allowNull: false }
  },
  {
    sequelize,
    modelName: Order.name,
  }
);

export default Order;
