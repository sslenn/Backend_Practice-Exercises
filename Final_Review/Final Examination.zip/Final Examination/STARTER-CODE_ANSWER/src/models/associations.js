import Product from "./product.js";
import Category from "./category.js";
import User from "./user.js";
import Order from "./order.js";

//
//  Define Sequlize models associations
//
export function setupAssociations() {
  // Category ↔ Product
  Category.hasMany(Product, { foreignKey: "categoryId", as: "products" });
  Product.belongsTo(Category, { foreignKey: "categoryId", as: "category" });

  // User ↔ Order
  User.hasMany(Order, { foreignKey: "userId", as: "orders" });
  Order.belongsTo(User, { foreignKey: "userId", as: "user" });

  // Product ↔ Order (1:*)
  Product.hasMany(Order, { foreignKey: "productId", as: "orders" });
  Order.belongsTo(Product, { foreignKey: "productId", as: "product" });
}
