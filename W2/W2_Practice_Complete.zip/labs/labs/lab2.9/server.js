// Lab2.9: CREATE — POST Form Handling (START CODE EX-3)
// TASK 1: Complete the POST /contact handler to save name to submissions.txt
// BONUS: validate empty name, return HTML confirmation, save as JSON

const http = require('http');
const fs = require('fs');

const server = http.createServer((req, res) => {
  const url = req.url;
  const method = req.method;

  console.log(`Received ${method} request for ${url}`);

  // GET / — home page
  if (url === '/' && method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    return res.end('Welcome to the Home Page');
  }

  // GET /contact — show the form
  if (url === '/contact' && method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    return res.end(`
      <html>
        <head><title>Contact</title></head>
        <body>
          <h2>Contact Form</h2>
          <form method="POST" action="/contact">
            <label>Name: <input type="text" name="name" placeholder="Your name" required /></label><br/><br/>
            <button type="submit">Submit</button>
          </form>
        </body>
      </html>
    `);
  }

  // POST /contact — receive and save form data
  if (url === '/contact' && method === 'POST') {
    let body = '';

    // 1. Buffer incoming data chunks
    req.on('data', chunk => {
      body += chunk.toString();
    });

    // 2. When all data has arrived, process it
    req.on('end', () => {
      const name = new URLSearchParams(body).get('name');
      console.log('Submitted name:', name);

      // BONUS: validate the name field is not empty
      if (!name || name.trim() === '') {
        res.writeHead(400, { 'Content-Type': 'text/html' });
        return res.end(`
          <html><body>
            <h2>Error: Name cannot be empty.</h2>
            <a href="/contact">Go back</a>
          </body></html>
        `);
      }

      // BONUS: save as JSON format instead of plain text
      const entry = JSON.stringify({ name: name.trim(), submittedAt: new Date().toISOString() });

      // 3. Append to submissions.txt (one JSON object per line)
      fs.appendFile('submissions.txt', entry + '\n', (err) => {
        if (err) {
          console.error('Failed to save submission:', err);
          res.writeHead(500, { 'Content-Type': 'text/plain' });
          return res.end('Internal Server Error: could not save submission.');
        }

        // 4. BONUS: Send back an HTML confirmation page
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(`
          <html>
            <head><title>Thank You</title></head>
            <body>
              <h2>Thank you, ${name.trim()}!</h2>
              <p>Your submission has been recorded.</p>
              <a href="/contact">Submit another</a>
            </body>
          </html>
        `);
      });
    });

    return; // important: don't fall through to the 404 handler
  }

  // Default — 404
  res.writeHead(404, { 'Content-Type': 'text/plain' });
  return res.end('404 Not Found');
});

server.listen(3000, () => {
  console.log('Server is running at http://localhost:3000');
});
